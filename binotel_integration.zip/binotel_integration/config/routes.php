<?php

defined('BASEPATH') or exit('No direct script access allowed');

$route['admin/binotel_integration'] = 'binotel_integration/index';
$route['admin/binotel_integration/receive_call'] = 'binotel_integration/receive_call';
$route['admin/binotel_integration/get_contacts'] = 'binotel_integration/get_contacts';
$route['binotel-integration/view'] = 'binotel_integration/view';
