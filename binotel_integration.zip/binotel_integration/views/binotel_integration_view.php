<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<h1>Binotel Integration</h1>
<p>Цей модуль інтегрує Binotel з Perfex CRM.</p>
