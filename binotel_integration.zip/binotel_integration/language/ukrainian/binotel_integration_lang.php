<?php
$lang['call_statistics'] = 'Статистика розмов';