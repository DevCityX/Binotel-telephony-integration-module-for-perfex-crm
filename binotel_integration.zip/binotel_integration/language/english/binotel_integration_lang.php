<?php


$lang['call_statistics'] = 'Call Statistics';